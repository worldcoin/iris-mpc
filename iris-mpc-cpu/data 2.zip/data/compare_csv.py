import csv
import sys
import json
import re

def normalize_json_string(json_str):
    """Normalize a JSON string to ensure consistent comparison."""
    try:
        # Parse the JSON
        parsed_json = json.loads(json_str)
        
        # If it's a list of link objects, sort by ID
        if isinstance(parsed_json, list) and len(parsed_json) > 0 and isinstance(parsed_json[0], dict):
            # Check if these are link objects with 'id' field
            if all('id' in item for item in parsed_json):
                # Sort the list by ID values, handling both {"id": X} and {"id": {"id": X}}
                def get_sort_key(item):
                    id_value = item['id']
                    if isinstance(id_value, dict) and 'id' in id_value:
                        return id_value['id']
                    return id_value
                
                parsed_json.sort(key=get_sort_key)
        
        # Re-serialize with consistent formatting
        return json.dumps(parsed_json, sort_keys=True)
    except json.JSONDecodeError:
        # If it's not valid JSON, return as is
        return json_str
    except Exception:
        # For any other errors, return as is
        return json_str

def normalize_string(value):
    """Normalize a string value for consistent comparison."""
    if not value:
        return value
    
    # Convert to string if not already
    value = str(value).strip()
    
    # Normalize JSON structures
    if value.startswith('[') or value.startswith('{'):
        return normalize_json_string(value)
    
    # Normalize numeric strings (remove leading zeros, etc.)
    if re.match(r'^-?\d+(\.\d+)?$', value):
        try:
            if '.' in value:
                return str(float(value))
            else:
                return str(int(value))
        except:
            pass
    
    # Case normalization for certain types of data
    # (Uncomment if needed)
    # value = value.lower()
    
    return value

def load_csv(filename):
    """Load CSV file and return a list of dictionaries."""
    result = []
    with open(filename, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Normalize all values for consistent comparison
            normalized_row = {key: normalize_string(value) for key, value in row.items()}
            result.append(normalized_row)
    return result

def compare_row_details(ref_row, comp_row):
    """Compare two rows and return details of differences."""
    differences = {}
    for key in ref_row:
        if not ref_row[key]:  # Skip empty values
            continue
        
        if key not in comp_row:
            differences[key] = {'ref': ref_row[key], 'comp': 'MISSING'}
        elif ref_row[key] != comp_row[key]:
            differences[key] = {'ref': ref_row[key], 'comp': comp_row[key]}
    
    return differences

def truncate_value(value, max_length=100):
    """Truncate long values for display."""
    value_str = str(value)
    if len(value_str) > max_length:
        return value_str[:max_length] + "... [truncated]"
    return value_str

def analyze_json_differences(ref_str, comp_str):
    """Analyze and report differences between two JSON strings."""
    try:
        ref_data = json.loads(ref_str)
        comp_data = json.loads(comp_str)
        
        # Handle array of link objects
        if isinstance(ref_data, list) and isinstance(comp_data, list):
            # Extract IDs for comparison, keeping original order
            ref_ids = []
            comp_ids = []
            ref_processed = []
            comp_processed = []
            
            for item in ref_data:
                if isinstance(item, dict) and 'id' in item:
                    # Handle both {"id": 5} and {"id": {"id": 5}}
                    id_value = item['id']
                    if isinstance(id_value, dict) and 'id' in id_value:
                        ref_ids.append(id_value['id'])
                        # Create normalized version for comparison
                        processed_item = item.copy()
                        processed_item['id'] = id_value['id']
                        ref_processed.append(processed_item)
                    else:
                        ref_ids.append(id_value)
                        ref_processed.append(item)
            
            for item in comp_data:
                if isinstance(item, dict) and 'id' in item:
                    # Handle both {"id": 5} and {"id": {"id": 5}}
                    id_value = item['id']
                    if isinstance(id_value, dict) and 'id' in id_value:
                        comp_ids.append(id_value['id'])
                        # Create normalized version for comparison
                        processed_item = item.copy()
                        processed_item['id'] = id_value['id']
                        comp_processed.append(processed_item)
                    else:
                        comp_ids.append(id_value)
                        comp_processed.append(item)
            
            # Sort both lists by ID for comparison
            ref_processed.sort(key=lambda x: x['id'])
            comp_processed.sort(key=lambda x: x['id'])
            
            # Sort ID lists for comparison
            ref_ids_sorted = sorted(ref_ids)
            comp_ids_sorted = sorted(comp_ids)
            
            # Find differences in IDs
            in_ref_not_comp = [id for id in ref_ids_sorted if id not in comp_ids_sorted]
            in_comp_not_ref = [id for id in comp_ids_sorted if id not in ref_ids_sorted]
            
            # Check for differences in items with same ID
            matching_ids = [id for id in ref_ids_sorted if id in comp_ids_sorted]
            structure_diffs = []
            
            for id_val in matching_ids:
                ref_item = next((item for item in ref_processed if item['id'] == id_val), None)
                comp_item = next((item for item in comp_processed if item['id'] == id_val), None)
                
                if ref_item != comp_item:
                    structure_diffs.append({
                        'id': id_val,
                        'ref': ref_item,
                        'comp': comp_item
                    })
            
            result = {
                'ref_count': len(ref_ids),
                'comp_count': len(comp_ids),
                'missing_from_comp': in_ref_not_comp,
                'extra_in_comp': in_comp_not_ref,
                'structure_differences': structure_diffs
            }
            
            # Provide a more concise summary
            summary_parts = []
            
            if len(in_ref_not_comp) > 0:
                summary_parts.append(f"{len(in_ref_not_comp)} IDs missing from comparison")
            
            if len(in_comp_not_ref) > 0:
                summary_parts.append(f"{len(in_comp_not_ref)} extra IDs in comparison")
            
            if len(structure_diffs) > 0:
                summary_parts.append(f"{len(structure_diffs)} items with matching IDs but different structure")
            
            if not summary_parts:
                if len(ref_ids) != len(comp_ids):
                    summary_parts.append(f"Both contain the same IDs but reference has {len(ref_ids)} and comparison has {len(comp_ids)} (possible duplicates)")
                else:
                    summary_parts.append("JSON arrays contain the same content in different order")
            
            result['summary'] = ", ".join(summary_parts)
            
            return result
        
        # For other JSON types
        return {'summary': "JSON structures differ in format"}
        
    except json.JSONDecodeError:
        return {'summary': "Invalid JSON format in one or both strings"}
    except Exception as e:
        return {'summary': f"Error comparing JSON: {str(e)}"}

def compare_csvs(reference_file, comparison_file, verbose=False):
    """Compare two CSV files by matching rows based on source_ref field."""
    try:
        reference_data = load_csv(reference_file)
        comparison_data = load_csv(comparison_file)
        
        print(f"Reference file: {reference_file} ({len(reference_data)} rows)")
        print(f"Comparison file: {comparison_file} ({len(comparison_data)} rows)")
        
        # Index comparison data by source_ref for faster lookups
        comp_by_source_ref = {}
        for row in comparison_data:
            if 'source_ref' in row:
                source_ref = row['source_ref']
                if source_ref not in comp_by_source_ref:
                    comp_by_source_ref[source_ref] = []
                comp_by_source_ref[source_ref].append(row)
        
        missing_source_refs = []
        diff_rows = []
        
        for i, ref_row in enumerate(reference_data):
            if 'source_ref' not in ref_row:
                print(f"Warning: Row {i+1} in reference file has no source_ref field")
                continue
                
            source_ref = ref_row['source_ref']
            
            # Check if this source_ref exists in comparison file
            if source_ref not in comp_by_source_ref:
                missing_source_refs.append((i, source_ref, ref_row))
                continue
                
            # Compare with all rows that have the same source_ref
            found_exact_match = False
            best_match = None
            best_differences = None
            min_diff_count = float('inf')
            
            for comp_row in comp_by_source_ref[source_ref]:
                differences = compare_row_details(ref_row, comp_row)
                
                if not differences:  # Perfect match
                    found_exact_match = True
                    break
                
                # Track the best match for this source_ref
                if len(differences) < min_diff_count:
                    min_diff_count = len(differences)
                    best_match = comp_row
                    best_differences = differences
            
            if not found_exact_match and best_differences:
                diff_rows.append((i, source_ref, ref_row, best_match, best_differences))
        
        # Report results
        if not missing_source_refs and not diff_rows:
            print(f"\n✅ All {len(reference_data)} rows from reference file match in the comparison file")
            return True
        
        if missing_source_refs:
            print(f"\n⚠️ Found {len(missing_source_refs)} source_refs in reference file missing from comparison file:")
            for i, source_ref, row in missing_source_refs:
                print(f"Row {i+1}: source_ref={source_ref}")
                if verbose:
                    truncated_row = {k: truncate_value(v) for k, v in row.items()}
                    print(f"  Full row: {truncated_row}")
        
        if diff_rows:
            print(f"\n⚠️ Found {len(diff_rows)} rows with differences for matching source_refs:")
            for i, source_ref, ref_row, comp_row, differences in diff_rows:
                print(f"Row {i+1}: source_ref={source_ref} has differences:")
                
                for key, diff in differences.items():
                    print(f"  - {key}:")
                    
                    # For links field, provide detailed JSON analysis
                    if key == 'links' and diff['ref'].startswith('[') and diff['comp'].startswith('['):
                        analysis = analyze_json_differences(diff['ref'], diff['comp'])
                        print(f"    DIFFERENCE SUMMARY: {analysis.get('summary', 'Unknown difference')}")
                        
                        if 'missing_from_comp' in analysis and analysis['missing_from_comp']:
                            print(f"    IDs in reference but missing from comparison: {analysis['missing_from_comp']}")
                        
                        if 'extra_in_comp' in analysis and analysis['extra_in_comp']:
                            print(f"    IDs in comparison but not in reference: {analysis['extra_in_comp']}")
                        
                        if 'structure_differences' in analysis and analysis['structure_differences']:
                            print(f"    Items with same ID but different structure: {len(analysis['structure_differences'])}")
                            if verbose:
                                for struct_diff in analysis['structure_differences'][:3]:  # Limit to first 3 for readability
                                    print(f"      ID {struct_diff['id']}:")
                                    print(f"        Reference: {struct_diff['ref']}")
                                    print(f"        Comparison: {struct_diff['comp']}")
                                if len(analysis['structure_differences']) > 3:
                                    print(f"      ... and {len(analysis['structure_differences']) - 3} more")
                        
                        print(f"    Reference has {analysis.get('ref_count', '?')} links, Comparison has {analysis.get('comp_count', '?')} links")
                        
                        if verbose:
                            print(f"    Reference (truncated): {truncate_value(diff['ref'])}")
                            print(f"    Comparison (truncated): {truncate_value(diff['comp'])}")
                    else:
                        # For non-JSON fields, show the values directly
                        print(f"    Reference: {truncate_value(diff['ref'])}")
                        print(f"    Comparison: {truncate_value(diff['comp'])}")
                
                if verbose:
                    # Print the full rows for context
                    print(f"  Reference row: {truncate_value(str(ref_row))}")
                    print(f"  Comparison row: {truncate_value(str(comp_row))}")
        
        return False
            
    except Exception as e:
        print(f"Error comparing files: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    verbose = False
    args = sys.argv[1:]
    
    # Check for verbose flag
    if "-v" in args or "--verbose" in args:
        verbose = True
        # Remove the flag from args
        if "-v" in args:
            args.remove("-v")
        if "--verbose" in args:
            args.remove("--verbose")
    
    if len(args) != 2:
        print("Usage: python compare_csv.py [-v|--verbose] <reference_file> <comparison_file>")
        print("  -v, --verbose: Show detailed differences for non-matching rows")
        print("  reference_file: Path to reference CSV file (which must be fully contained in comparison_file)")
        print("  comparison_file: Path to CSV file to compare against reference")
        sys.exit(1)
    
    reference_file = args[0]
    comparison_file = args[1]
    
    success = compare_csvs(reference_file, comparison_file, verbose)
    sys.exit(0 if success else 1)
