### Run Scipt
python3 compare_csv.py graph_500.csv genesis_links_500.csv -v
